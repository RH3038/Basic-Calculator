public class Main extends Calc{

	public static void main(String[] args) {
		
		Calc calc = new Calc();
		
		calc.setFrame();
		calc.setField();
		calc.buttonLayout();
		calc.setPanel();
		calc.setCPanel();
		calc.setPane();
		calc.buttonClick();
	}
}


